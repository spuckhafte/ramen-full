# ramen

Utility for **Naruto Botto**.

**Official Server:** https://discord.gg/eEeaExspU8

### DOES not VIOLATES nb's TOS :)

# Features
1. Slash only.
2. Reminds you for your tasks.
3. Show you the cooldowns for your tasks.
4. Shows you online users, playing NB. (*you can also hide from coming into this list*)
5. Shows you the leaderboard for missions and reports.
6. Plans your balance, just react to: *n balance*.
7. A global and local (server-specific) leaderboard for missions and reports.
