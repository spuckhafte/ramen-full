export default {
    TOKEN: "MTAxNjA0MzM4OTk5NDY2ODA3Mw.GWiaEg._PkcOBMsl3XxZNVdVO3MUIpZKpiX09X_84aMv8",
    DB_URL: "mongodb+srv://shit-chat:hesoyam@cluster0.1at1u.mongodb.net/ramen?retryWrites=true&w=majority",
    MOD_CHNLS: ["1017459544273715210"],
    REDIS_URL: "redis://default:maL09tX2Ak5xkfaklQrtX9AiK60NBLL9@redis-15597.c212.ap-south-1-1.ec2.cloud.redislabs.com:15597",
    IMP_SERVERS: {
        '1008657622691479633': {
            server: 'uhhm',
            mod: ['856184519442694154'],
            db_refer: 'server1'
        },

        '990468363404857356': {
            server: 'ⴵ Taishoku',
            mod: ['987669538764095549'],
            db_refer: 'server2'
        }
    }
};